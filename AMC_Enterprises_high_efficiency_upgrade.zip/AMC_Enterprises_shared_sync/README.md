# AMC Enterprises — high-efficiency website upgrade

This version keeps the existing AMC Enterprises design and adds:

- SEO metadata, canonical URL and structured data
- Google Maps and IndiaMART quick links
- WhatsApp cart ordering
- Product search/category catalogue experience
- Genuine-review submission + admin approval workflow
- Expanded About/Business information, FAQ and Contact/support sections
- Shared-cloud product, settings, orders and enquiries data
- Product-request workflow + admin queue
- Order tracking by order number + checkout phone
- Admin analytics and CSV order report export
- Low-stock visibility through the existing inventory status
- Customer accounts with shared order history
- Browser notifications for new orders while the admin dashboard is open
- PWA manifest, service worker and install prompt

## Before deploying

1. Run the updated `schema.sql` once in the Supabase SQL Editor. It adds `product_requests`, `reviews`, `customer_accounts`, and the `customer_account_id` link on orders.
2. Keep the existing Vercel environment variables. Recommended additional variable: `CUSTOMER_SESSION_SECRET` (a long random value). If it is absent, the customer account API falls back to `ADMIN_SESSION_SECRET`.
3. Deploy this folder to the existing Vercel project.

Automated SMS and official automated WhatsApp API messaging are intentionally not enabled because they require a third-party provider/account and may incur usage charges. The free WhatsApp ordering link and browser notifications are included.
