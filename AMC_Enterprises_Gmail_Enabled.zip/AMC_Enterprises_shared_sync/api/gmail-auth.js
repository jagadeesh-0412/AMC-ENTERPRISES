const { requireAdmin } = require('../lib/auth');
const { GMAIL_SCOPE, oauthConfig, signState, verifyState, encrypt, exchangeCode, getGmailProfile, getSettings, updateSettings } = require('../lib/gmail');

module.exports = async (req, res) => {
  try {
    const action = String(req.query?.action || 'status');
    if (!requireAdmin(req, res)) return;

    if (req.method === 'GET' && action === 'connect') {
      const { clientId, redirectUri } = oauthConfig(req);
      const state = signState({ exp: Date.now() + 10 * 60 * 1000, nonce: require('crypto').randomUUID() });
      const params = new URLSearchParams({ client_id: clientId, redirect_uri: redirectUri, response_type: 'code', access_type: 'offline', prompt: 'consent', scope: GMAIL_SCOPE, state });
      res.writeHead(302, { Location: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}` });
      return res.end();
    }

    if (req.method === 'GET' && action === 'callback') {
      const state = verifyState(req.query?.state);
      if (!state) return res.status(400).send('Gmail authorization state is invalid or expired. Return to AMC Admin and try again.');
      const code = String(req.query?.code || '');
      if (!code) return res.status(400).send('Google did not return an authorization code.');
      const tokens = await exchangeCode(req, code);
      if (!tokens.refresh_token) return res.status(400).send('Google did not return a refresh token. Disconnect Gmail and connect again with consent enabled.');
      const accessToken = tokens.access_token;
      const profile = await getGmailProfile(accessToken);
      await updateSettings({ gmail_enabled: true, gmail_address: profile.emailAddress || '', gmail_refresh_token_enc: encrypt(tokens.refresh_token), gmail_connected_at: new Date().toISOString() });
      res.writeHead(302, { Location: '/?gmail=connected#gmail-settings' });
      return res.end();
    }

    if (req.method === 'GET' && action === 'status') {
      const settings = await getSettings();
      return res.json({ connected: !!settings?.gmail_refresh_token_enc, enabled: settings?.gmail_enabled !== false && !!settings?.gmail_refresh_token_enc, email: settings?.gmail_address || '', connectedAt: settings?.gmail_connected_at || '' });
    }

    if (req.method === 'POST' && action === 'disconnect') {
      await updateSettings({ gmail_enabled: false, gmail_address: '', gmail_refresh_token_enc: '', gmail_connected_at: '' });
      return res.json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (e) {
    return res.status(e.status || 500).json({ error: e.message, details: e.data || null });
  }
};
